console.log("Bot iniciado com sucesso!");
// Aqui você pode colocar seu código do bot
